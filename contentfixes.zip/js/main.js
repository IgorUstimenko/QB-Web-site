AOS.init();

window.addEventListener("load", event => {
  AOS.refresh();
});
