// window.onscroll = function () {
//     let html = document.documentElement,
//         body = document.body;
//     // Скрипт для замены nav на маску с другими стилями

//     let navStyle = document.querySelector('.main-nav').style,
//         maskNavStyle = document.querySelector('.mask-nav').style;
//     if (html.scrollTop > 2020 || body.scrollTop > 2020) {
//         navStyle.display = "none";
//         maskNavStyle.opacity = 1;

//     } else {
//         navStyle.display = "flex";
//         maskNavStyle.opacity = 0;
//     }

// };
